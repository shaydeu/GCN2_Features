#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  4 10:01:50 2020

@author: shay
"""

from __future__ import division
from __future__ import print_function

import time
import argparse
import numpy as np
import networkx as nx 
import torch
import torch.nn.functional as F
import torch.optim as optim
from scipy.io import loadmat
from pygcn.utils import load_data, accuracy
from pygcn.models import GCN
from scipy.sparse import csr_matrix
import scipy
from timeit import default_timer as timer
# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
#parser.add_argument('--epochs', type=int, default=200,
#                    help='Number of epochs to train.')
parser.add_argument('--epochs', type=int, default=2000,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')

# Load data
adj, features, labels, idx_train, idx_val, idx_test = load_data()
#start = timeit.timeit()
start = timer()
A = adj
A = A.to_dense()
A = A.numpy()
features_A= features
features_A = features.numpy()

#scipy.io.savemat('/Users/shaydeutsch/Dropbox/Aligned_Transfer_Learning/code/labels_citeceer.mat', mdict={'labels_A': labels_A})
#scipy.io.savemat('/home/shay/Dropbox/Aligned_Transfer_Learning/code/A_cora.mat', mdict={'A': A})
#scipy.io.savemat('/Users/shaydeutsch/Dropbox/Aligned_Transfer_Learning/code/features_Cora.mat', mdict={'features_A': features_A})
G =  nx.from_numpy_matrix(A)
b = nx.edge_betweenness_centrality(G)
values_b = b.values()
keys_b = b.keys()
x = np.zeros((np.shape(adj)))
A1 = np.zeros((np.shape(adj)))                
for (k,v) in b.items():
    x[k] = v
    A1[k] = 1      
y = x.transpose()
z = np.add(x, y)
A2 = np.zeros((np.shape(adj)))
A2 = np.transpose(A1)
A_unweighted = np.add(A1, A2)
np.fill_diagonal(A_unweighted, 0)
#end = timer()
#end = timeit.timeit()
end = timer()
print(end - start) 
#print("Total time elapsed: {:.4f}s".format(time.time() - t_total))
#print(end - start)

# Train model
print("Optimization Finished!")
#print("Total time elapsed: {:.4f}s".format(time.time() - t_total))

# Testing

