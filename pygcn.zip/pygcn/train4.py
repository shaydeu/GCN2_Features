from __future__ import division
from __future__ import print_function

import time
import argparse
import numpy as np
import networkx as nx 
import torch
import torch.nn.functional as F
import torch.optim as optim
from scipy.io import loadmat
from pygcn.utils import load_data, accuracy
from pygcn.models import GCN
from scipy.sparse import csr_matrix
import scipy
# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=42, help='Random seed.')
#parser.add_argument('--epochs', type=int, default=200,
#                    help='Number of epochs to train.')
parser.add_argument('--epochs', type=int, default=2000,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=16,
                    help='Number of hidden units.')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

# Load data
adj, features, labels, idx_train, idx_val, idx_test = load_data()
#start = timeit.timeit()
print("hello")
A = adj
A = A.to_dense()
A = A.numpy()
features_A= features
features_A = features.numpy()

labels_A=  labels
labels_A = labels_A.numpy()
#scipy.io.savemat('/Users/shaydeutsch/Dropbox/Aligned_Transfer_Learning/code/labels_citeceer.mat', mdict={'labels_A': labels_A})
#scipy.io.savemat('/home/shay/Dropbox/Aligned_Transfer_Learning/code/A_cora.mat', mdict={'A': A})
#scipy.io.savemat('/Users/shaydeutsch/Dropbox/Aligned_Transfer_Learning/code/features_Cora.mat', mdict={'features_A': features_A})
G =  nx.from_numpy_matrix(A)
b = nx.edge_betweenness_centrality(G)
values_b = b.values()
keys_b = b.keys()
x = np.zeros((np.shape(adj)))
A1 = np.zeros((np.shape(adj)))                
for (k,v) in b.items():
    x[k] = v
    A1[k] = 1      
y = x.transpose()
z = np.add(x, y)
A2 = np.zeros((np.shape(adj)))
A2 = np.transpose(A1)
A_unweighted = np.add(A1, A2)
np.fill_diagonal(A_unweighted, 0)
#end = timeit.timeit()
#print(end - start)
G =  nx.from_numpy_matrix(A_unweighted)
b = nx.edge_betweenness_centrality(G)
values_b = b.values()
keys_b = b.keys()
x = np.zeros((np.shape(adj)))                
for (k,v) in b.items():
    x[k] = v
    A1[k] = 1      
y = x.transpose()
z = np.add(x, y)
GB =  nx.from_numpy_matrix(z)
colsum = z.sum(axis=0)
colsum2 = A_unweighted.sum(axis=0)
temp =   colsum.sum(axis=0)
temp2 =  GB.number_of_edges()
temp3 =  np.divide(temp,temp2)/2
degree = np.zeros(len(z))
degree = np.divide(colsum,colsum2);
np.fill_diagonal(z,degree)
#np.fill_diagonal(z,temp3)
D = np.sum(z, axis=0)
D_inv = D**-0.5
#D_inv = np.diag(D_inv)
a1 = z * D_inv
A_hat = D_inv * a1
adj = torch.from_numpy(A_hat)
#adj = torch.from_numpy(A)
adj = adj.to_sparse()
adj= adj.float()
#scipy.io.savemat('/Users/shaydeutsch/Dropbox/Aligned_Transfer_Learning/code/Citeceer_B.mat', mdict={'z': z})
#scipy.io.savemat('/Users/shaydeutsch/Dropbox/Aligned_Transfer_Learning/code/Citeceer_A.mat', mdict={'W': A_unweighted })
# Model and optimizer
model = GCN(nfeat=features.shape[1],
            nhid=args.hidden,
            nclass=labels.max().item() + 1,
            dropout=args.dropout)
optimizer = optim.Adam(model.parameters(),
                       lr=args.lr, weight_decay=args.weight_decay)

if args.cuda:
    model.cuda()
    features = features.cuda()
    adj = adj.cuda()
    labels = labels.cuda()
    idx_train = idx_train.cuda()
    idx_val = idx_val.cuda()
    idx_test = idx_test.cuda()


def train(epoch):
    t = time.time()
    model.train()
    optimizer.zero_grad()
    output = model(features, adj)
    loss_train = F.nll_loss(output[idx_train], labels[idx_train])
    acc_train = accuracy(output[idx_train], labels[idx_train])
    loss_train.backward()
    optimizer.step()

    if not args.fastmode:
        # Evaluate validation set performance separately,
        # deactivates dropout during validation run.
        model.eval()
        output = model(features, adj)

    loss_val = F.nll_loss(output[idx_val], labels[idx_val])
    acc_val = accuracy(output[idx_val], labels[idx_val])
    print('Epoch: {:04d}'.format(epoch+1),
          'loss_train: {:.4f}'.format(loss_train.item()),
          'acc_train: {:.4f}'.format(acc_train.item()),
          'loss_val: {:.4f}'.format(loss_val.item()),
          'acc_val: {:.4f}'.format(acc_val.item()),
          'time: {:.4f}s'.format(time.time() - t))


def test():
    model.eval()
    output = model(features, adj)
    loss_test = F.nll_loss(output[idx_test], labels[idx_test])
    acc_test = accuracy(output[idx_test], labels[idx_test])
    print("Test set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "accuracy= {:.4f}".format(acc_test.item()))


# Train model
t_total = time.time()
for epoch in range(args.epochs):
    train(epoch)
print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))

# Testing
test()
