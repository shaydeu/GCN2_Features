#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 24 15:01:22 2020

@author: shaydeutsch
"""
import networkx as nx 
import numpy as np
A = adj.to_dense()
A = A.numpy()

G =  nx.from_numpy_matrix(A)
print("Degree centrality")
import networkx as nx 
import numpy as np
b = nx.edge_betweenness_centrality(G)

print("Degree centrality")
nx.draw(G)
plt.show()

values_b = b.values()
keys_b = b.keys()
x = np.zeros((np.shape(adj)))

for (k,v) in b.items():
			x[k] = v
	  
y = x.transpose()
z = np.add(x, y)
