import numpy as np
import scipy.sparse as sp
import torch
import networkx as nx 



def encode_onehot(labels):
    classes = set(labels)
    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in
                    enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)),
                             dtype=np.int32)
    return labels_onehot


def load_data(path="../data/cora/", dataset="cora"):
    """Load citation network dataset (cora only for now)"""
    print('Loading {} dataset...'.format(dataset))

    idx_features_labels = np.genfromtxt("{}{}.content".format(path, dataset),
                                        dtype=np.dtype(str))
    features = sp.csr_matrix(idx_features_labels[:, 1:-1], dtype=np.float32)
    labels = encode_onehot(idx_features_labels[:, -1])

    # build graph
    idx = np.array(idx_features_labels[:, 0], dtype=np.int32)
    idx_map = {j: i for i, j in enumerate(idx)}
    edges_unordered = np.genfromtxt("{}{}.cites".format(path, dataset),
                                    dtype=np.int32)
    edges = np.array(list(map(idx_map.get, edges_unordered.flatten())),
                     dtype=np.int32).reshape(edges_unordered.shape)
    adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])),
                        shape=(labels.shape[0], labels.shape[0]),
                        dtype=np.float32)

    # build symmetric adjacency matrix
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)

    features = normalize(features)
    adj = normalize(adj + sp.eye(adj.shape[0]))
    #adj = Bet_mat(adj)
#    A = adj
#    A = A.to_dense()
#    A = A.numpy()
#    G =  nx.from_numpy_matrix(A)
#    b = nx.edge_betweenness_centrality(G)
#    values_b = b.values()
#    keys_b = b.keys()
#    x = np.zeros((np.shape(adj)))
#                    
#    for (k,v) in b.items():
#        x[k] = v
#    y = x.transpose()
#    z = np.add(x, y)
#    adj = torch.from_numpy(z)
#    adj = adj.to_sparse()
#    adj= adj.float()
    

    idx_train = range(140)
    idx_val = range(200, 500)
    idx_test = range(500, 1500)

    features = torch.FloatTensor(np.array(features.todense()))
    labels = torch.LongTensor(np.where(labels)[1])
    adj = sparse_mx_to_torch_sparse_tensor(adj)

    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)

    return adj, features, labels, idx_train, idx_val, idx_test


# def normalize(mx):
#     """Row-normalize sparse matrix"""
#     rowsum = np.array(mx.sum(1))
#     r_inv = np.power(rowsum, -1).flatten()
#     r_inv[np.isinf(r V_inv)] = 0
#     r_mat_inv = sp.diags(r_inv)
#     mx = r_mat_inv.dot(mx)
#     return mx


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)

def Bet_mat(adj):
    A = adj
    A = A.to_dense()
    A = A.numpy()
    G =  nx.from_numpy_matrix(A)
    b = nx.edge_betweenness_centrality(G)
    values_b = b.values()
    keys_b = b.keys()
    x = np.zeros((np.shape(adj)))
    for (k,v) in b.items():
         x[k] = v
         y = x.transpose()
         z = np.add(x, y)
         adj = torch.from_numpy(z)
    return adj

def Compute_Betweeness_Centrality(A):
    
    import numpy as np
    from sklearn.linear_model import LinearRegression
    import random
    import pickle as pkl
    import torch
    import networkx as nx
    
    np.fill_diagonal(A, 0)
    [m, n] = A.shape
    
    G =  nx.from_numpy_matrix(A)
    b = nx.edge_betweenness_centrality(G)
    values_b = b.values()
    keys_b = b.keys()
    A2 = np.zeros((np.shape(A)))                  
    for (k,v) in b.items():
        A2[k]=v
        
    y = A2.transpose()
    z_sub   = 10*np.add(A2, y)
    ## Divide by mean vertex degree value 
    BC = z_sub.sum(axis=0)
    BC = BC/np.mean(BC)
    
    return z_sub, BC

def compute_graph_features(adj):
    
    from utils import Compute_Betweeness_Centrality
    from utils import Dim_Red
    from utils import compute_norm_lap
    from numpy import linalg as LA
    import scipy.sparse as sp
    import numpy as np
    import torch
    import numpy
    from control import dlyap
    
    A = adj
    A = A.to_dense()
    A = A.numpy()
    #A = adj.numpy()
    np.fill_diagonal(A, 0)
    [m, n] = A.shape
     
    [z, BC] = Compute_Betweeness_Centrality(A)
    L_norm = compute_norm_lap(z)
    I = np.identity(m)    
    print("Compute Sylvester features")
    X = dlyap(z,L_norm,I)
    #X = X.transpose()
    dimension_reduced = 1000
    X = Dim_Red(X,dimension_reduced)
    X = X.transpose()
    feats = torch.FloatTensor(X)
    return feats 

def Dim_Red(X,dimension_reduced):
    import numpy as np
    import networkx as nx
    import scipy
    import torch
    
    u, s, vh = np.linalg.svd(X)
    u1 = u [0:dimension_reduced,:]
    X = u.transpose()
    X = X.transpose()
    mean = X.mean(0)
    var = X.std(0)
    X = (X - mean) / (var + 1e-6)
    return X

def compute_norm_lap(A):
    import networkx as nx
    import numpy as np
    from numpy import linalg as LA
    from scipy.linalg import eigh
    from networkx.utils import not_implemented_for
    G =  nx.from_numpy_matrix(A)
    A1 = nx.normalized_laplacian_matrix(G)
    L_norm = A1.todense()
    return L_norm
   #  n, m = A.shape
   #  np.fill_diagonal(A, 0)
   #  diags = A.sum(axis=1)
   #  diags = np.sqrt(diags)
   #  diag_inv =1/diags 
   #  D = np.diagflat(diag_inv)
   # # diag=_sqrt[np.isinf(diag_sqrt)] = 0
   #  I = np.identity(m)     
   #  A_norm = np.matmul(A, D)
   #  A_norm = np.matmul(D, A_norm)
   #  L_norm = I - A_norm 
    
# """ Here - Optional compute dimensionality reduction using SVD
# """ 
# # dimension_reduced = 800
# # X = Dim_Red(X,dimension_reduced)